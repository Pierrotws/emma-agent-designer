
Kawa support
    current version: 1.9.1
    tested version: 1.9.1
    other working versions: 

Clojure support
    current version: git-repo, snapshot 1.1.0-alpha, August 28, 2009
    tested version: git-repo, snapshot 1.1.0-aplha, August 28, 2009


