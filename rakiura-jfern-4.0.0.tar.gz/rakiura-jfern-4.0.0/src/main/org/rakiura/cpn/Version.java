
package org.rakiura.cpn;

public class Version {
  
  public static final String COPYRIGHT = "Copyright (C) 1999-2009 by Mariusz Nowostawski and others.";
  public static final String VERSION = "4.0.0";
  public static final String NAME = "rakiura-jfern";
  public static final String FULLNAME = "Rakiura JFern Petri Net Simulator";

  public static String banner(){
    return FULLNAME + "  ("+NAME+")"+"    version "+VERSION+"\n"+COPYRIGHT+"\nAll Rights Reserved.\n\n";
  }
}
